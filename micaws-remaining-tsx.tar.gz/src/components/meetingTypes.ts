export type TranscriptSegment = {
  time: number;
  speaker: string | null;
  text: string;
};
